<?php
require 'db.php';
$records = [];
foreach ($pdo->query("SELECT student_name, att_date, status FROM attendance ORDER BY att_date") as $r) {
    $records[$r['att_date']][$r['student_name']] = $r['status'];
}
$extra = $pdo->query("SELECT name FROM attendance_students ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
// (object) keeps an empty result as {} instead of [] in JSON
echo json_encode(['records' => (object)$records, 'extra' => $extra]);
