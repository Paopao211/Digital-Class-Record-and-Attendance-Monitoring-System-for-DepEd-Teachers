<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$sql = "INSERT INTO grades 
(student_name,subject,category,activity_name,score,total,quarter,date)
VALUES (?,?,?,?,?,?,?,?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssddss",
$data['student_name'],
$data['subject'],
$data['category'],
$data['activity_name'],
$data['score'],
$data['total'],
$data['quarter'],
$data['date']
);

$stmt->execute();

echo json_encode(["status"=>"success"]);
?>