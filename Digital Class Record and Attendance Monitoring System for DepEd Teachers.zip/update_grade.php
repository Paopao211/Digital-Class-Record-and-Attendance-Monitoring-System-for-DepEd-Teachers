<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$sql = "UPDATE grades SET
student_name=?,
subject=?,
category=?,
activity_name=?,
score=?,
total=?,
quarter=?,
date=?
WHERE id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssddssi",
$data['student_name'],
$data['subject'],
$data['category'],
$data['activity_name'],
$data['score'],
$data['total'],
$data['quarter'],
$data['date'],
$data['id']
);

$stmt->execute();

echo json_encode(["status"=>"updated"]);
?>