<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Registration Form (Right Side)</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

  <style>
    body {
      background-image: url('image/back2.png');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      min-height: 100vh;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: flex-end;  /* pushes content to right */
      padding-right: 3vw;        /* nice gap from edge */
    }

    /* container animation */
    .form-container {
      animation: slideFade 3s ease;
    }

    @keyframes slideFade {
      from {
        opacity: 0;
        transform: translateY(40px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* placeholder gradient */
    .form-control::placeholder {
      color: transparent;
      background: linear-gradient(to right, #000000, #FFFFFF);
      -webkit-background-clip: text;
      background-clip: text;
      -webkit-text-fill-color: transparent;
      font-style: italic;
    }

    /* register button animation */
    #register {
      width: 300px;
      height: 40px;
      font-size: 20px;
      border-radius: 50px;
      background-color: blue;
      color: white;
      border: none;
      transition: 0.3s ease;
    }

    #register:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
    }

    /* login link animation */
    .login-link {
      color: red;
      text-decoration: underline;
      display: inline-block;
      transition: 0.3s ease;
    }

    .login-link:hover {
      transform: translateY(-2px);
      color: #ff9900;
    }

    /* make the card responsive on small screens */
    @media (max-width: 768px) {
      body {
        justify-content: center;
        padding-right: 0;
        padding: 1rem;
      }
      .form-container {
        width: 100% !important;
      }
    }
  </style>

  <script>
    $(document).ready(function () {

      $("#register").click(function () {
        let email_address = $("#email_address").val().trim();
        let password = $("#password").val().trim();
        let first_name = $("#first_name").val().trim();
        let middle_name = $("#middle_name").val().trim();
        let last_name = $("#last_name").val().trim();

        if (email_address == "" || password == "" || first_name == "" || middle_name == "" || last_name == "") {
          alert("Please complete all the fields!");
          return;
        }

        $.ajax({
          url: 'create_user.php',
          type: 'POST',
          dataType: 'json',
          data: {
            email_address: email_address,
            password: password,
            first_name: first_name,
            middle_name: middle_name,
            last_name: last_name
          }
        })
        .done(function (response) {
          alert('Request successful: ' + response['msg']);
          $("#email_address, #password, #first_name, #middle_name, #last_name").val("");
        })
        .fail(function () {
          alert('Error occurred');
        });
      });

      /* login animation before redirect */
      $(".login-link").click(function (e) {
        e.preventDefault();
        let link = $(this);
        link.css("opacity", "0.5");

        setTimeout(function () {
          window.location.href = "index.php";
        }, 300);
      });

    });
  </script>
</head>

<body>

  <!-- container is now pushed to the right via flexbox on body -->
  <div class="form-container shadow-lg rounded"
       style="width: 380px; max-width: 90vw; border-radius: 40px; padding: 30px; background-color: #FFFFFF;">

    <h1 class="text-center mb-4">Register Account</h1>

    <form>
      <div class="mb-3 text-start">
        <label class="form-label">Email address</label>
        <input type="email" class="form-control" id="email_address" placeholder="Email Address">
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password">
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">First Name</label>
        <input type="text" class="form-control" id="first_name" placeholder="First Name">
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Middle Name</label>
        <input type="text" class="form-control" id="middle_name" placeholder="Middle Name">
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Last Name</label>
        <input type="text" class="form-control" id="last_name" placeholder="Last Name">
      </div>

      <div class="text-center">
        <button type="button" id="register">
          <i class="bi bi-person-add"></i> Register
        </button>
      </div>

      <div class="text-center mt-3">
        <p style="color: blue;">
          Login here?
          <a href="index.php" class="login-link">login</a>
        </p>
      </div>
    </form>

  </div>

</body>
</html>