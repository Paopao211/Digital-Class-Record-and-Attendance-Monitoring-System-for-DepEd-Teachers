<?php
$conn = new mysqli(
"sql109.infinityfree.com",
"if0_38378242",
"Lf3C2cMhu1IaLK2",
"if0_38378242_php"
);

if($conn->connect_error){
die("Connection failed: ".$conn->connect_error);
}
?>