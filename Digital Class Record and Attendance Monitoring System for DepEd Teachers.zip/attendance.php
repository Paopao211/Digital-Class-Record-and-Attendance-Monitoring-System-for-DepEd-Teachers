<!DOCTYPE html>
<html>
  <head>
    
    <meta charset="utf8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}html{scroll-padding-top:env(safe-area-inset-top,0px)}body{margin:0;padding:0;font:14px -apple-system,BlinkMacSystemFont,sans-serif;background:#faf9f5;color:#141413}img{max-width:100%}[hidden]:not([hidden=until-found i]){display:none!important}</style></head><body>
<title>Klase Attendance</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700;800&amp;family=Figtree:wght@400;500;600&amp;family=JetBrains+Mono:wght@500;700&amp;display=swap">
<style>
/* Layout: one column on phones; on wide screens a sticky summary rail sits beside the register. Ink-on-paper record book with red-pencil absences. */
:root{
  --paper:#f6f5f1; --card:#ffffff; --ink:#1d2433; --muted:#68707f; --line:#dedbd2;
  --accent:#2b4fd8; --accent-ink:#ffffff;
  --p:#1f8a5b; --p-bg:#dff3e8; --l:#a86a00; --l-bg:#fbeccb; --a:#c8302f; --a-bg:#fbdedc; --e:#3b6db3; --e-bg:#dce8f8;
  --f-display:"Bricolage Grotesque","Trebuchet MS",sans-serif; --f-body:"Figtree",system-ui,sans-serif; --f-mono:"JetBrains Mono",ui-monospace,monospace;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --paper:#12151c; --card:#1b202b; --ink:#e9ebf0; --muted:#98a0b0; --line:#2c3342;
  --accent:#7d9bff; --accent-ink:#0f1320;
  --p:#55d39a; --p-bg:#173b2c; --l:#f0b84f; --l-bg:#43340f; --a:#ff7d7a; --a-bg:#4a1f1f; --e:#8db7ef; --e-bg:#1d3150; color-scheme:dark}}
:root[data-theme="dark"]{
  --paper:#12151c; --card:#1b202b; --ink:#e9ebf0; --muted:#98a0b0; --line:#2c3342;
  --accent:#7d9bff; --accent-ink:#0f1320;
  --p:#55d39a; --p-bg:#173b2c; --l:#f0b84f; --l-bg:#43340f; --a:#ff7d7a; --a-bg:#4a1f1f; --e:#8db7ef; --e-bg:#1d3150; color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--paper);color:var(--ink);font-family:var(--f-body);font-size:15px;line-height:1.5;padding-inline:16px;padding-block:20px 48px}
.wrap{max-width:1040px;margin-inline:auto}
button,input,select{font:inherit;color:inherit}
button{cursor:pointer}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
header{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:flex-end;justify-content:space-between;padding-bottom:16px;border-bottom:2px solid var(--ink)}
.eyebrow{font-family:var(--f-mono);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
h1{font-family:var(--f-display);font-weight:800;font-size:clamp(26px,5vw,38px);line-height:1.05;margin:4px 0 0;text-wrap:balance;letter-spacing:-.01em}
.meta{min-width:0;font-size:13px;color:var(--muted)}
.meta b{color:var(--ink);font-weight:600}
.example{margin-top:12px;padding:8px 12px;border:1px dashed var(--line);border-radius:6px;font-size:13px;color:var(--muted);display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;justify-content:space-between}
.example button{border:1px solid var(--line);background:var(--card);border-radius:6px;padding:4px 10px;font-size:13px}
.tabs{display:flex;gap:4px;margin-block:18px 16px;border-bottom:1px solid var(--line);overflow-x:auto}
.tabs button{background:none;border:0;border-bottom:3px solid transparent;padding:10px 14px;font-weight:600;color:var(--muted);white-space:nowrap}
.tabs button[aria-selected="true"]{color:var(--ink);border-bottom-color:var(--accent)}
.grid{display:grid;grid-template-columns:1fr;gap:20px}
@media(min-width:900px){.grid{grid-template-columns:minmax(0,1fr) 260px;align-items:start}.rail{position:sticky;top:16px}}
.rail{display:grid;gap:12px;min-width:0}
.rate{background:var(--ink);color:var(--paper);border-radius:10px;padding:16px}
.rate .big{font-family:var(--f-display);font-weight:800;font-size:46px;line-height:1;font-variant-numeric:tabular-nums}
.rate .lbl{font-family:var(--f-mono);font-size:11px;letter-spacing:.1em;text-transform:uppercase;opacity:.7}
.bar{height:8px;border-radius:4px;background:rgba(127,127,127,.35);margin-top:12px;overflow:hidden}
.bar i{display:block;height:100%;background:var(--p);width:0}
.counts{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.count{border-radius:8px;padding:8px 4px;text-align:center}
.count b{display:block;font-family:var(--f-mono);font-size:20px;font-variant-numeric:tabular-nums}
.count span{font-size:11px}
.cP{background:var(--p-bg);color:var(--p)}.cL{background:var(--l-bg);color:var(--l)}.cA{background:var(--a-bg);color:var(--a)}.cE{background:var(--e-bg);color:var(--e)}
.risk{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;font-size:13px}
.risk h3{margin:0 0 6px;font-size:13px;font-family:var(--f-mono);letter-spacing:.08em;text-transform:uppercase;color:var(--a)}
.risk ul{margin:0;padding:0;list-style:none;display:grid;gap:4px}
.risk li{display:flex;justify-content:space-between;gap:8px}
.panel{background:var(--card);border:1px solid var(--line);border-radius:10px;min-width:0}
.toolbar{display:flex;flex-wrap:wrap;gap:10px 16px;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid var(--line)}
.toolbar label{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:2px}
input[type=date],input[type=text]{background:var(--paper);border:1px solid var(--line);border-radius:6px;padding:7px 10px;min-width:0}
.btn{border:1px solid var(--line);background:var(--card);border-radius:6px;padding:7px 12px;font-weight:600;font-size:13px}
.btn.primary{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.rows{list-style:none;margin:0;padding:0}
.row{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--line)}
.row:last-child{border-bottom:0}
.who{min-width:0;flex:1 1 150px}
.who b{display:block;font-weight:600;overflow-wrap:anywhere}
.who small{font-family:var(--f-mono);font-size:11px;color:var(--muted)}
.seg{display:flex;gap:4px}
.seg button{width:44px;height:38px;border-radius:6px;border:1px solid var(--line);background:var(--paper);font-family:var(--f-mono);font-weight:700;color:var(--muted)}
.seg button[aria-pressed="true"][data-c="P"]{background:var(--p);border-color:var(--p);color:var(--paper)}
.seg button[aria-pressed="true"][data-c="L"]{background:var(--l);border-color:var(--l);color:var(--paper)}
.seg button[aria-pressed="true"][data-c="A"]{background:var(--a);border-color:var(--a);color:var(--paper)}
.seg button[aria-pressed="true"][data-c="E"]{background:var(--e);border-color:var(--e);color:var(--paper)}
.legend{display:flex;flex-wrap:wrap;gap:6px 14px;padding:10px 14px;font-size:12px;color:var(--muted);border-top:1px solid var(--line)}
.legend code{font-family:var(--f-mono);font-weight:700;color:var(--ink)}
.scroll{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{padding:7px 8px;text-align:center;border-bottom:1px solid var(--line);white-space:nowrap}
th{font-family:var(--f-mono);font-size:11px;font-weight:500;color:var(--muted);letter-spacing:.04em}
td:first-child,th:first-child{text-align:left;position:sticky;left:0;background:var(--card);min-width:140px;max-width:180px;overflow:hidden;text-overflow:ellipsis}
.cell{display:inline-block;width:26px;height:26px;line-height:26px;border-radius:5px;font-family:var(--f-mono);font-weight:700;font-size:12px}
.cell.P{background:var(--p-bg);color:var(--p)}.cell.L{background:var(--l-bg);color:var(--l)}.cell.A{background:var(--a-bg);color:var(--a)}.cell.E{background:var(--e-bg);color:var(--e)}.cell.N{color:var(--line)}
.pill{display:inline-block;font-family:var(--f-mono);font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px}
.pill.ok{background:var(--p-bg);color:var(--p)}.pill.risk{background:var(--a-bg);color:var(--a)}.pill.na{color:var(--muted)}
.tnum{font-variant-numeric:tabular-nums;font-family:var(--f-mono)}
.add{display:flex;flex-wrap:wrap;gap:8px;padding:12px 14px;border-bottom:1px solid var(--line)}
.add input{flex:1 1 180px}
.x{border:0;background:none;color:var(--muted);font-size:13px;padding:6px 8px;text-decoration:underline}
.empty{padding:28px 14px;text-align:center;color:var(--muted)}
.status{font-size:12px;color:var(--muted);margin-top:16px;text-align:right}
@media(prefers-reduced-motion:no-preference){.bar i{transition:width .3s}}
</style>

<div class="wrap">
  <header>
    <div>
      <div class="eyebrow" id="sy">School Year 2026-2027</div>
      <h1 id="clsname">Grade 7 - Sampaguita</h1>
    </div>
    <div class="meta">Adviser: <b id="adviser">Ms. Reyes</b><br>Target attendance: <b>90%</b></div>
  </header>

  <div class="example" id="example">
    <span>Sample students and attendance are shown so you can see how it works.</span>
    <button id="clear" type="button">Clear samples and start fresh</button>
  </div>

  <nav class="tabs" role="tablist" aria-label="Sections">
    <button role="tab" id="t-today" aria-selected="true" data-tab="today">Mark attendance</button>
    <button role="tab" id="t-record" aria-selected="false" data-tab="record">Class record</button>
    <button role="tab" id="t-students" aria-selected="false" data-tab="students">Students</button>
  </nav>

  <div class="grid">
    <main>
      <section id="today" class="panel">
        <div class="toolbar">
          <label for="day">Date<input type="date" id="day"></label>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn" id="allP" type="button">Mark all present</button>
            <button class="btn" id="clearDay" type="button">Clear this day</button>
          </div>
        </div>
        <ul class="rows" id="list"><li class="row"><div class="who"><b>Maria Santos</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Maria Santos"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Juan Dela Cruz</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Juan Dela Cruz"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Angela Reyes</b><small>80% so far</small></div><div class="seg" role="group" aria-label="Attendance for Angela Reyes"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Miguel Garcia</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Miguel Garcia"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Sofia Ramos</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Sofia Ramos"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Paolo Bautista</b><small>40% so far</small></div><div class="seg" role="group" aria-label="Attendance for Paolo Bautista"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Isabel Mendoza</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Isabel Mendoza"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Carlo Villanueva</b><small>80% so far</small></div><div class="seg" role="group" aria-label="Attendance for Carlo Villanueva"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Bianca Flores</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Bianca Flores"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li><li class="row"><div class="who"><b>Rafael Aquino</b><small>100% so far</small></div><div class="seg" role="group" aria-label="Attendance for Rafael Aquino"><button type="button" data-c="P" aria-pressed="false">P</button><button type="button" data-c="L" aria-pressed="false">L</button><button type="button" data-c="A" aria-pressed="false">A</button><button type="button" data-c="E" aria-pressed="false">E</button></div></li></ul>
        <div class="legend"><span><code>P</code> Present</span><span><code>L</code> Late</span><span><code>A</code> Absent</span><span><code>E</code> Excused</span></div>
      </section>

      <section id="record" class="panel" hidden="">
        <div class="scroll"><table id="tbl"><thead><tr><th>Student</th><th>Wed<br>Sep 23</th><th>Thu<br>Sep 24</th><th>Fri<br>Sep 25</th><th>Mon<br>Sep 28</th><th>Tue<br>Sep 29</th><th>P</th><th>L</th><th>A</th><th>E</th><th>Rate</th><th>Status</th></tr></thead><tbody><tr><td>Maria Santos</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">5</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Juan Dela Cruz</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell L">L</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">4</td><td class="tnum">1</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Angela Reyes</td><td><span class="cell P">P</span></td><td><span class="cell A">A</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">4</td><td class="tnum">0</td><td class="tnum">1</td><td class="tnum">0</td><td class="tnum">80%</td><td><span class="pill risk">At risk</span></td></tr><tr><td>Miguel Garcia</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell E">E</span></td><td><span class="cell P">P</span></td><td class="tnum">4</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">1</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Sofia Ramos</td><td><span class="cell L">L</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">4</td><td class="tnum">1</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Paolo Bautista</td><td><span class="cell A">A</span></td><td><span class="cell A">A</span></td><td><span class="cell P">P</span></td><td><span class="cell A">A</span></td><td><span class="cell P">P</span></td><td class="tnum">2</td><td class="tnum">0</td><td class="tnum">3</td><td class="tnum">0</td><td class="tnum">40%</td><td><span class="pill risk">At risk</span></td></tr><tr><td>Isabel Mendoza</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">5</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Carlo Villanueva</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell A">A</span></td><td><span class="cell P">P</span></td><td><span class="cell L">L</span></td><td class="tnum">3</td><td class="tnum">1</td><td class="tnum">1</td><td class="tnum">0</td><td class="tnum">80%</td><td><span class="pill risk">At risk</span></td></tr><tr><td>Bianca Flores</td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">5</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr><tr><td>Rafael Aquino</td><td><span class="cell P">P</span></td><td><span class="cell E">E</span></td><td><span class="cell E">E</span></td><td><span class="cell P">P</span></td><td><span class="cell P">P</span></td><td class="tnum">3</td><td class="tnum">0</td><td class="tnum">0</td><td class="tnum">2</td><td class="tnum">100%</td><td><span class="pill ok">OK</span></td></tr></tbody></table></div>
        <div class="legend">Showing the last 10 days with entries. Attendance = (Present + Late) / (days recorded - Excused).</div>
      </section>

      <section id="students" class="panel" hidden="">
        <form class="add" id="addForm">
          <label for="newName" style="position:absolute;left:-9999px">Student name</label>
          <input type="text" id="newName" placeholder="Full name, e.g. Ana Lopez" autocomplete="off">
          <button class="btn primary" type="submit">Add student</button>
        </form>
        <ul class="rows" id="roster"><li class="row"><div class="who"><b>Maria Santos</b><small>No. 1</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Juan Dela Cruz</b><small>No. 2</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Angela Reyes</b><small>No. 3</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Miguel Garcia</b><small>No. 4</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Sofia Ramos</b><small>No. 5</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Paolo Bautista</b><small>No. 6</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Isabel Mendoza</b><small>No. 7</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Carlo Villanueva</b><small>No. 8</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Bianca Flores</b><small>No. 9</small></div><button type="button" class="x">Remove</button></li><li class="row"><div class="who"><b>Rafael Aquino</b><small>No. 10</small></div><button type="button" class="x">Remove</button></li></ul>
      </section>
    </main>

    <aside class="rail" aria-label="Summary for selected day">
      <div class="rate">
        <div class="lbl" id="rateLbl">Attendance on Sep 30</div>
        <div class="big" id="rate">--</div>
        <div class="bar"><i id="rateBar" style="width: 0px;"></i></div>
      </div>
      <div class="counts">
        <div class="count cP"><b id="nP">0</b><span>Present</span></div>
        <div class="count cL"><b id="nL">0</b><span>Late</span></div>
        <div class="count cA"><b id="nA">0</b><span>Absent</span></div>
        <div class="count cE"><b id="nE">0</b><span>Excused</span></div>
      </div>
      <div class="risk" id="risk"><h3>Below 90%</h3><ul><li><span>Paolo Bautista</span><span class="tnum">40%</span></li><li><span>Angela Reyes</span><span class="tnum">80%</span></li><li><span>Carlo Villanueva</span><span class="tnum">80%</span></li></ul></div>
    </aside>
  </div>
  <div class="status" id="status"></div>
</div>

<script>
(function(){
  var CODES=["P","L","A","E"], THRESH=0.9;
  var state=null, db=null, docRef=null, tab="today", timer=null, sampleMode=false;
  var $=function(id){return document.getElementById(id)};

  function iso(d){return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
  function todayISO(){return iso(new Date())}
  function fmt(s,long){var d=new Date(s+"T00:00:00");return d.toLocaleDateString("en-PH",long?{weekday:"long",month:"long",day:"numeric"}:{month:"short",day:"numeric"})}
  function dow(s){return new Date(s+"T00:00:00").toLocaleDateString("en-PH",{weekday:"short"})}

  function sample(){
    var names=["Maria Santos","Juan Dela Cruz","Angela Reyes","Miguel Garcia","Sofia Ramos","Paolo Bautista","Isabel Mendoza","Carlo Villanueva","Bianca Flores","Rafael Aquino"];
    var pat=["PPPPP","PPLPP","PAPPP","PPPEP","LPPPP","AAPAP","PPPPP","PPAPL","PPPPP","PEEPP"];
    var days=[],d=new Date();d.setDate(d.getDate()-1);
    while(days.length<5){if(d.getDay()!==0&&d.getDay()!==6)days.unshift(iso(d));d.setDate(d.getDate()-1)}
    var rec={};
    days.forEach(function(day,k){rec[day]={};names.forEach(function(n,i){rec[day]["s"+(i+1)]=pat[i][k]})});
    return {cls:"Grade 7 - Sampaguita",adviser:"Ms. Reyes",sy:"School Year 2026-2027",
      students:names.map(function(n,i){return {id:"s"+(i+1),name:n}}),records:rec,sample:true,nextId:11};
  }

  function stats(id){
    var c={P:0,L:0,A:0,E:0},days=Object.keys(state.records);
    days.forEach(function(d){var v=state.records[d][id];if(c[v]!==undefined)c[v]++});
    var rec=c.P+c.L+c.A+c.E,den=rec-c.E;
    return {c:c,rec:rec,rate:den>0?(c.P+c.L)/den:null};
  }

  function save(){
    setStatus("Saving...");
    clearTimeout(timer);
    timer=setTimeout(function(){
      if(docRef){
        docRef.set({json:JSON.stringify(state)}).then(function(){setStatus("Saved")}).catch(function(){setStatus("Could not save. Your changes are only in this open page.")});
      }else{
        try{localStorage.setItem("klase-attendance",JSON.stringify(state));setStatus("Saved on this device")}
        catch(e){setStatus("Changes are kept only while this page is open.")}
      }
    },400);
  }
  function setStatus(t){$("status").textContent=t}

  function currentDay(){return $("day").value||todayISO()}

  function renderToday(){
    var day=currentDay(), rec=state.records[day]||{}, list=$("list");
    list.innerHTML="";
    if(!state.students.length){list.innerHTML='<li class="empty">No students yet. Add them in the Students tab.</li>';return}
    state.students.forEach(function(s){
      var li=document.createElement("li");li.className="row";
      var who=document.createElement("div");who.className="who";
      var b=document.createElement("b");b.textContent=s.name;
      var sm=document.createElement("small");var st=stats(s.id);
      sm.textContent=st.rate===null?"No record yet":Math.round(st.rate*100)+"% so far";
      who.appendChild(b);who.appendChild(sm);
      var seg=document.createElement("div");seg.className="seg";seg.setAttribute("role","group");seg.setAttribute("aria-label","Attendance for "+s.name);
      CODES.forEach(function(c){
        var bt=document.createElement("button");bt.type="button";bt.textContent=c;bt.dataset.c=c;
        bt.setAttribute("aria-pressed",rec[s.id]===c?"true":"false");
        bt.onclick=function(){setMark(day,s.id,rec[s.id]===c?null:c)};
        seg.appendChild(bt);
      });
      li.appendChild(who);li.appendChild(seg);list.appendChild(li);
    });
  }

  function setMark(day,id,c){
    if(!state.records[day])state.records[day]={};
    if(c===null)delete state.records[day][id];else state.records[day][id]=c;
    if(!Object.keys(state.records[day]).length)delete state.records[day];
    changed();
  }

  function renderSummary(){
    var day=currentDay(), rec=state.records[day]||{}, c={P:0,L:0,A:0,E:0};
    state.students.forEach(function(s){if(c[rec[s.id]]!==undefined)c[rec[s.id]]++});
    ["P","L","A","E"].forEach(function(k){$("n"+k).textContent=c[k]});
    var den=c.P+c.L+c.A;
    $("rateLbl").textContent="Attendance on "+fmt(day);
    if(den>0){var r=(c.P+c.L)/den;$("rate").textContent=Math.round(r*100)+"%";$("rateBar").style.width=(r*100)+"%"}
    else{$("rate").textContent="--";$("rateBar").style.width="0"}
    var risk=state.students.map(function(s){return {s:s,st:stats(s.id)}}).filter(function(x){return x.st.rate!==null&&x.st.rate<THRESH}).sort(function(a,b){return a.st.rate-b.st.rate});
    var box=$("risk");box.innerHTML="";
    var h=document.createElement("h3");h.textContent="Below 90%";box.appendChild(h);
    if(!risk.length){var p=document.createElement("div");p.textContent="No students at risk.";box.appendChild(p)}
    else{var ul=document.createElement("ul");risk.forEach(function(x){var li=document.createElement("li");var a=document.createElement("span");a.textContent=x.s.name;var b=document.createElement("span");b.className="tnum";b.textContent=Math.round(x.st.rate*100)+"%";li.appendChild(a);li.appendChild(b);ul.appendChild(li)});box.appendChild(ul)}
  }

  function renderRecord(){
    var days=Object.keys(state.records).sort().slice(-10), t=$("tbl");
    t.innerHTML="";
    if(!days.length){t.innerHTML='<tr><td class="empty" style="text-align:center">No attendance marked yet.</td></tr>';return}
    var thead=document.createElement("thead"),tr=document.createElement("tr");
    var th=document.createElement("th");th.textContent="Student";tr.appendChild(th);
    days.forEach(function(d){var h=document.createElement("th");h.innerHTML=dow(d)+"<br>"+fmt(d);tr.appendChild(h)});
    ["P","L","A","E","Rate","Status"].forEach(function(x){var h=document.createElement("th");h.textContent=x;tr.appendChild(h)});
    thead.appendChild(tr);t.appendChild(thead);
    var tb=document.createElement("tbody");
    state.students.forEach(function(s){
      var r=document.createElement("tr"),n=document.createElement("td");n.textContent=s.name;r.appendChild(n);
      days.forEach(function(d){var td=document.createElement("td"),v=(state.records[d]||{})[s.id];var sp=document.createElement("span");sp.className="cell "+(v||"N");sp.textContent=v||"-";td.appendChild(sp);r.appendChild(td)});
      var st=stats(s.id);
      ["P","L","A","E"].forEach(function(k){var td=document.createElement("td");td.className="tnum";td.textContent=st.c[k];r.appendChild(td)});
      var rt=document.createElement("td");rt.className="tnum";rt.textContent=st.rate===null?"-":Math.round(st.rate*100)+"%";r.appendChild(rt);
      var sd=document.createElement("td"),pl=document.createElement("span");
      if(st.rate===null){pl.className="pill na";pl.textContent="-"}else if(st.rate<THRESH){pl.className="pill risk";pl.textContent="At risk"}else{pl.className="pill ok";pl.textContent="OK"}
      sd.appendChild(pl);r.appendChild(sd);tb.appendChild(r);
    });
    t.appendChild(tb);
  }

  function renderRoster(){
    var ul=$("roster");ul.innerHTML="";
    if(!state.students.length){ul.innerHTML='<li class="empty">Your class list is empty. Type a name above and press Add student.</li>';return}
    state.students.forEach(function(s,i){
      var li=document.createElement("li");li.className="row";
      var who=document.createElement("div");who.className="who";
      var b=document.createElement("b");b.textContent=s.name;var sm=document.createElement("small");sm.textContent="No. "+(i+1);
      who.appendChild(b);who.appendChild(sm);
      var rm=document.createElement("button");rm.type="button";rm.className="x";rm.textContent="Remove";
      rm.onclick=function(){
        if(rm.dataset.sure!=="1"){rm.dataset.sure="1";rm.textContent="Tap again to remove";setTimeout(function(){rm.dataset.sure="";rm.textContent="Remove"},3000);return}
        state.students=state.students.filter(function(x){return x.id!==s.id});
        Object.keys(state.records).forEach(function(d){delete state.records[d][s.id];if(!Object.keys(state.records[d]).length)delete state.records[d]});
        changed();
      };
      li.appendChild(who);li.appendChild(rm);ul.appendChild(li);
    });
  }

  function renderTabs(){
    ["today","record","students"].forEach(function(k){
      $(k).hidden=(k!==tab);
      $("t-"+k).setAttribute("aria-selected",k===tab?"true":"false");
    });
  }

  function renderAll(){
    $("clsname").textContent=state.cls;$("adviser").textContent=state.adviser;$("sy").textContent=state.sy;
    $("example").hidden=!state.sample;
    renderTabs();renderToday();renderSummary();renderRecord();renderRoster();
  }
  function changed(){renderAll();save()}

  document.querySelectorAll("[data-tab]").forEach(function(b){b.onclick=function(){tab=b.dataset.tab;renderTabs()}});
  $("day").onchange=function(){renderToday();renderSummary()};
  $("allP").onclick=function(){var day=currentDay();state.records[day]=state.records[day]||{};state.students.forEach(function(s){state.records[day][s.id]="P"});changed()};
  $("clearDay").onclick=function(){delete state.records[currentDay()];changed()};
  $("clear").onclick=function(){state.students=[];state.records={};state.sample=false;state.nextId=1;changed()};
  $("addForm").onsubmit=function(e){
    e.preventDefault();var v=$("newName").value.trim();if(!v)return;
    state.students.push({id:"s"+(state.nextId++),name:v});$("newName").value="";
    if(state.sample){/* keep sample flag until cleared */}
    changed();
  };

  function boot(loaded){
    state=loaded||sample();
    if(!state.nextId)state.nextId=state.students.length+1;
    $("day").value=todayISO();
    renderAll();
  }

  // Start with local copy so the page is usable at once, then upgrade to shared storage if available.
  var local=null;
  try{var raw=localStorage.getItem("klase-attendance");if(raw)local=JSON.parse(raw)}catch(e){}
  boot(local);

  if(window.claude&&window.claude.use){
    window.claude.use("db").then(function(d){
      if(!d)return;
      db=d;docRef=db.doc("register/main");
      return docRef.get().then(function(snap){
        var data=snap&&(typeof snap.data==="function"?snap.data():snap);
        if(data&&data.json){try{state=JSON.parse(data.json);if(!state.nextId)state.nextId=state.students.length+1;renderAll();setStatus("Loaded saved register")}catch(e){}}
        else{save()}
      });
    }).catch(function(){docRef=null});
  }
})();
</script>

</body></html>