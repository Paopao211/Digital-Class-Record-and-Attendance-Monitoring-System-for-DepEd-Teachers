<?php
require 'db.php';
$d = input();
$action = $d['action'] ?? '';
$date   = $d['date'] ?? date('Y-m-d');
$name   = trim($d['name'] ?? '');
$valid  = ['P', 'L', 'A', 'E'];

$upsert = "INSERT INTO attendance (student_name, att_date, status) VALUES (?,?,?)
           ON DUPLICATE KEY UPDATE status = VALUES(status)";

switch ($action) {
    case 'mark':            // one student, one day (code = null clears it)
        $code = $d['code'] ?? null;
        if ($code === null) {
            $pdo->prepare("DELETE FROM attendance WHERE student_name=? AND att_date=?")->execute([$name, $date]);
        } elseif (in_array($code, $valid, true)) {
            $pdo->prepare($upsert)->execute([$name, $date, $code]);
        }
        break;
    case 'all_present':     // whole class present for a day
        $st = $pdo->prepare($upsert);
        foreach (($d['names'] ?? []) as $n) { $st->execute([trim($n), $date, 'P']); }
        break;
    case 'clear_day':
        $pdo->prepare("DELETE FROM attendance WHERE att_date=?")->execute([$date]);
        break;
    case 'add_student':
        if ($name !== '') $pdo->prepare("INSERT IGNORE INTO attendance_students (name) VALUES (?)")->execute([$name]);
        break;
    case 'remove_student':
        $pdo->prepare("DELETE FROM attendance_students WHERE name=?")->execute([$name]);
        $pdo->prepare("DELETE FROM attendance WHERE student_name=?")->execute([$name]);
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
        exit;
}
echo json_encode(['ok' => true]);
