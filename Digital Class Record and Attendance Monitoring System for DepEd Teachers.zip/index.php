<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Grading System</title>

   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

   <!-- Bootstrap Icons -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

   <!-- jQuery -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

   <style>
    html, body {
    height: 100%;
    margin: 0;
}
     body {
        background-image: url('image/P1.png');
        background-size:cover;
        background-position: center;
        background-repeat: no-repeat;
        animation: fadeIn 2s ease-in-out;
     }

     /* Fade-in effect for whole page */
     @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
     }

     /* Slide-in animation for login box */
     .login-box {
        animation: slideUp 0.9s ease-out;
     }

     @keyframes slideUp {
        from {
          transform: translateY(50px);
          opacity: 0;
        }
        to {
          transform: translateY(0px);
          opacity: 1;
        }
     }

     /* Login button glow animation */
     .btn-glow {
        animation: glowing 2s infinite;
     }

     @keyframes glowing {
        0% { box-shadow: 0 0 5px #ff0000; }
        50% { box-shadow: 0 0 20px #ff6600; }
        100% { box-shadow: 0 0 5px #ff0000; }
     }

   </style>

<script type="text/javascript">
  $(document).ready(function(){
    $("#login").click(function(){
      let email_address = $("#email_address").val();
      let password = $("#password").val();

      $.ajax({
        url: 'login_user_ajax.php',
        type: 'POST',
        dataType: 'json',
        data: {
          email_address: email_address,
          password: password
        }
      })
      .done(function(response) {
        if (response['isValidUser'] === 1) {
          alert('Login successful: ' + response['msg']);
          window.location.href = 'login.php';
        } else {
          alert('Login Failed: ' + response['msg']);
        }
      })
      .fail(function(jqXHR, textStatus, errorThrown) {
        alert('Error occurred: ' + jqXHR.statusText + ' ' + jqXHR.responseText);
      });
    });
  });
</script>

</head>
<body>
  
<div class="container">
   <div class="col-md-4 mx-auto">
      <div class="shadow-lg rounded login-box" style="min-height: 300px; border-radius: 30px; padding:30px; background: rgba(255,255,255,0.8); margin-top:50px;">
        
        <div style="text-align:center;">
         <img src="image/logo.png" style="width:100px;height:100px; animation: fadeIn 1s;">
			 <h3 style="animation: fadeIn 1.5s; color:blue;">Welcome Back</h3>
    
        </div>

        <form method="POST">
          <div class="mb-4">
            <label for="email_address" class="form-label">Email Address</label>
            <input type="email" placeholder="Email or Phone Number" required class="form-control" style="border-radius: 50px;" id="email_address">
          </div>

     
      <div class="mb-3 position-relative">
  <input type="password" placeholder="Password" required
         class="form-control"
         style="border-radius:50px; padding-right:45px;"
         id="password">

  <i class="bi bi-eye-slash"
     id="togglePassword"
     style="position:absolute; right:15px; top:50%; transform:translateY(-50%);
            cursor:pointer; font-size:18px;"></i>
</div>
<script>
function togglePassword() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

          <div class="d-flex justify-content-center mt-1">
           <button type="button" class="btn btn-primary me-2" id="login" 
   style="width:300px; height:40px; font-size:20px; border-radius:50px;
        background-color:blue; color:white; border:none;">
  <i class="bi bi-person-plus-fill"></i> Login
</button>

          </div>

          <div class="text-center mt-4">
            <p style="color:black;">
              Don’t have an account?
             <a href="register.php" class="create-link">Create Account</a>

<style>
.create-link{
    color: red;
    text-decoration: none;
    position: relative;
}

.create-link::after{
    content: "";
    position: absolute;
    width: 0;
    height: 2px;
    left: 0;
    bottom: -3px;
    background: red;
    transition: 0.3s;
}

.create-link:hover::after{
    width: 100%;
}
</style>
            </p>
          </div>

        </form>

      </div>
   </div>
</div>


<script>
const toggle = document.getElementById("togglePassword");
const password = document.getElementById("password");

toggle.addEventListener("click", function () {
    const type = password.getAttribute("type") === "password" ? "text" : "password";
    password.setAttribute("type", type);

    this.classList.toggle("bi-eye");
    this.classList.toggle("bi-eye-slash");
});
</script>
</body>
</html>
